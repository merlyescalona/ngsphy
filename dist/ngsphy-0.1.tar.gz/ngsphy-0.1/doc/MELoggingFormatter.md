    def __init__(self,fmt,datefmt):
    def format(self, record):
