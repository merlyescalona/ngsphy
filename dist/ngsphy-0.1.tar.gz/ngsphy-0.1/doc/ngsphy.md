    def __init__(self,args):
    def run(self):
    def generateFolderStructure(self):
    def log(self, level, message):
    def getLogLevel(self,level):
    def ending(self, good, message):
def handlingCmdArguments():
        choices=LOG_LEVEL_CHOICES, default="INFO",\
