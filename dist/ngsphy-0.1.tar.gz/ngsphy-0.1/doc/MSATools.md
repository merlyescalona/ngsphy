def parseMSAFile(fastapath):
def parseMSAFileWithDescriptions(fastapath):
def isFasta(filepath):
def parseIndividualRelationFile(filepath):
