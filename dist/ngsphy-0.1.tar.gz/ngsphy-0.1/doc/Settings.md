    def __init__(self,filename):
        # default settings can be established.
    def checkArgs(self):
    def checkSectionGeneral(self,parserMessageCorrect,parserMessageWrong):
    def checkSectionData(self,parserMessageCorrect,parserMessageWrong):
    def checkIndelibleControlFile(self,parserMessageCorrect,parserMessageWrong):
    def checkSectionNGSReadsArt(self,parserMessageCorrect,parserMessageWrong):
    def checkSectionReadCount(self,parserMessageCorrect,parserMessageWrong):
                self.appLogger.warning("[read-count] section. Using default references.")
    def checkSectionCoverage(self,parserMessageCorrect,parserMessageWrong):
    def checkSectionExecution(self,parserMessageCorrect,parserMessageWrong):
    def checkSimPhyProjectValid(self)
    def formatSettingsMessage(self):
