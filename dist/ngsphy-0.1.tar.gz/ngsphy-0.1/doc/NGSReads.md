    def __init__(self):
    def addLine(self, line):
    def __init__(self,settings):
    def generateFolderStructure(self):
    def writeSeedFile(self):
    def writeSGEScript(self):
    def writeSLURMScript(self):
    def computeCoverageMatrix(self, nInds, nLoci,expCov, indCov, locCov):
    def writeCoverageMatrixIntoFile(self, coverageMatrix, filename):
    def getCommands(self):
    def writeBashScript(self):
    def commandLauncher(self, command):
    def run(self):
    def generateFolderStructureNGS(self):
    def printRunningInfo(self):
