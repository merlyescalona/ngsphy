#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse,copy,csv,datetime,logging,os,subprocess,sys,multiprocessing,threading,time,warnings
import numpy as np
import random as rnd
import settings as sp
from msatools import *
from coverage import NGSPhyDistribution as ngsphydistro

try:
	from collections import Counter
except ImportError:
	from counter import Counter

def getScoreSingle(data):
	"""
	Calulates a single Phred score.
	----------------------------------------------------------------------------
	Parameters:
	- data: the data that will be processed
	Returns:
	- the Phred score of the given value
	"""
	self.appLogger.debug("getScoreSingle(data)")
	if data!=0:
		return -10*np.log10(data)
	else:
		return 0
def getScoreMatrix(data):
	"""
	Calulates the Phred score of a matrix.
	----------------------------------------------------------------------------
	Parameters:
	- data: the data that will be processed
	Returns:
	- the Phred score of the given values
	"""
	self.appLogger.debug("getScoreMatrix(data)")
	value=np.copy(data)
	with warnings.catch_warnings():
		warnings.filterwarnings('error')
		try:
			value=-10*np.log10(data)
		except:
			pass
		infs=np.inf==value
		value[infs]=0
	return value

class RunningInfo:
	"""
	Class for the storage of running time information Reads Countsc Class
	Separated to be able to be used by several threads.
	"""
	def __init__(self, filename):
		self.filename=filename
		# self.appLogger=logging.getLogger('sngsw')
		self.lock = threading.Lock()
		self.lock.acquire()
		f=open(self.filename,"w")
		f.write("indexST,indexLOC,indID,inputFile,cpuTime,seed,outputFilePrefix\n")
		f.close()
		self.lock.release()


	def addLine(self, line):
		"""
		Adds a line to the running information estructure
		"""
		# self.appLogger.debug('Waiting for lock')
		self.lock.acquire()
		try:
			# self.appLogger.debug('Acquired lock')
			f=open(self.filename,"a")
			f.write(
				str(line[0])+","+\
				str(line[1])+","+\
				str(line[2])+","+\
				str(line[3])+","+\
				str(line[4])+","+\
				str(line[5])+","+\
				line[6]+"\n"
			)
			f.close()
		finally:
			# self.appLogger.debug('Released lock')
			self.lock.release()

class ReadCounts:
	"""
	Class to generate READ COUNTS of the given dataset
	----------------------------------------------------------------------------
	Atributes:
	- __NUCLEOTIDES: constant array with possible nucleotides characters
	- appLogger: logger to store status of the process flow
	- settings: Settings object withh all the program parameters
	- runningInfo: varible to store timing information of the processes.
	Structure to be shared across threads.
	- coverageFolderPath: path of the coverage matrix distribution.
	- readcountFolderPath: path where read count data will be stored.
	- readcountTrueFolderPath: path where true read count data will be stored.
	- readcountSampledFolderPath: path where sampled read count data will be
	stored.
	- referencesFolderPath: path where the reference used for the read counts
	are stored.
	- numSpeciesTrees: number of species tree.
	- numLociPerSpeciesTree: list with the number of loci per species tree
	- numIndividualsPerSpeciesTree: list with the number of individuals per
	species tree.
	- numSpeciesTreesDigits: number of digits that represent numSpeciesTrees
	- numLociPerSpeciesTreeDigits: list of the number of digits that represent
	numLociPerSpeciesTree.
	- numIndividualsPerSpeciesTreeDigits: list of the number of digits that represent
	numIndividualsPerSpeciesTree.
	- filteredST: identifiers of the species tree replicates that will be used.
	"""

	__NUCLEOTIDES=["A","C","G","T"]
	appLogger=None
	settings=None
	runningInfo=None
	# path related variables
	coverageFolderPath=""
	readcountFolderPath=""
	readcountTrueFolderPath=""
	readcountSampledFolderPath=""
	referencesFolderPath=""

	numSpeciesTrees=None
	numLociPerSpeciesTree=[]
	numIndividualsPerSpeciesTree=[]
	numSpeciesTreesDigits=[]
	numLociPerSpeciesTreeDigits=[]
	numIndividualsPerSpeciesTreeDigits=[]
	filteredST=[]

	def __init__(self,settings):
		self.appLogger=logging.getLogger('ngsphy')
		self.appLogger.info('Read counts.')
		self.settings=settings

		self.numSpeciesTrees=self.settings.parser.getint("general", "numspeciestrees")
		cc=self.settings.parser.get("general", "numLociPerSpeciesTree").strip().split(",")
		self.numLociPerSpeciesTree=[ int(item) for item in cc if not item ==""]
		cc=self.settings.parser.get("general", "numIndividualsPerSpeciesTree").strip().split(",")
		self.numIndividualsPerSpeciesTree=[ int(item) for item in cc if not item == ""]
		self.numSpeciesTreesDigits=len(str(self.numSpeciesTrees))
		self.numLociPerSpeciesTreeDigits=[len(str(item)) for item in self.numLociPerSpeciesTree]
		self.numIndividualsPerSpeciesTreeDigits=[len(str(item )) for item in self.numIndividualsPerSpeciesTree]
		self.filteredST=[int(item) for item in self.settings.parser.get("general", "filtered_ST").strip().split(",")]

		# Generating folder structure
		infoFile="{0}/{1}.info".format(
			self.settings.outputFolderPath,\
			self.settings.projectName
		)
		self.runningInfo=RunningInfo(infoFile)
		self.appLogger.info("File with timings of the [ngs-read-count] per loci can be find on:\t{0}".format(infoFile))

		# naming variables for shorter codeline
		self.coverageFolderPath="{0}/coverage".format(self.settings.outputFolderPath)
		self.readcountFolderPath="{0}/reads".format(self.settings.outputFolderPath)
		self.readcountTrueFolderPath="{0}/reads/true".format(self.settings.outputFolderPath)
		self.readcountSampledFolderPath="{0}/reads/sampled".format(self.settings.outputFolderPath)
		self.referencesFolderPath="{0}/refereces".format(self.settings.outputFolderPath)

		self.generateFolderStructureGeneral()

	def generateFolderStructureGeneral(self):
		"""
		Generates basic folder structure needed for Read Count option.
		This includes the folders:
		- reads
		- reads/true
		- reads/sampled
		- refereces
		"""
		self.appLogger.debug("generateFolderStructureGeneral(self)")
		# Checking output path
		self.appLogger.info("Creating folder structure for [ngs-read-count]")
		try:
			os.makedirs(self.readcountFolderPath)
			self.appLogger.info("Generating output folder ({0})".format(self.readcountFolderPath))
		except:
			self.appLogger.debug("Output folder exists ({0})".format(self.readcountFolderPath))
		try:
			os.makedirs(self.readcountTrueFolderPath)
			self.appLogger.info("Generating output folder ({0})".format(self.readcountTrueFolderPath))
		except:
			self.appLogger.debug("Output folder exists ({0})".format(self.readcountTrueFolderPath))
		try:
			os.makedirs(self.readcountSampledFolderPath)
			self.appLogger.info("Generating output folder ({0})".format(self.readcountSampledFolderPath))
		except:
			self.appLogger.debug("Output folder exists ({0})".format(self.readcountSampledFolderPath))
		try:
			os.makedirs(self.referencesFolderPath)
			self.appLogger.info("Generating output folder ({0})".format(self.referencesFolderPath))
		except:
			self.appLogger.debug("Output folder exists ({0})".format(self.referencesFolderPath))

	def generateFolderStructureDetail(self):
		"""
		Generates detailed folder structure needed for Read Count option.
		This includes:
		- Replicate folders  (as many as species tree replicates)
		- true/sampled folder per replicate.
		- These folders will contain the VCF files (true and sampled)
		"""
		self.appLogger.debug("generateFolderStructureDetail(self)")
		for i in range(0,len(self.filteredST)):
			indexST=self.filteredST[i]
			trueFolder="{0}/{1:0{2}d}".format(\
				self.readcountTrueFolderPath,\
				indexST,\
				self.numSpeciesTreesDigits)
			self.appLogger.debug("{0}|{1}".format(i, self.filteredST[i]))
			sampledFolder="{0}/{1:0{2}d}".format(\
				self.readcountSampledFolderPath,\
				indexST,\
				self.numSpeciesTreesDigits)
			references="{0}/{1:0{2}d}".format(\
				self.referencesFolderPath,\
				indexST,\
				self.numSpeciesTreesDigits)
			try:
				os.makedirs(trueFolder)
				self.appLogger.info("Generating output folder ({0})".format(trueFolder))
			except:
				self.appLogger.debug("Output folder exists ({0})".format(trueFolder))
			try:
				os.makedirs(sampledFolder)
				self.appLogger.info("Generating output folder ({0})".format(sampledFolder))
			except:
				self.appLogger.debug("Output folder exists ({0})".format(sampledFolder))
			try:
				os.makedirs(references)
				self.appLogger.info("Generating output folder ({0})".format(references))
			except:
				self.appLogger.debug("Output folder exists ({0})".format(references))


	def retrieveCoverageMatrix(self, indexST):
		"""
		Reads coverage matrix for a specific species tree identifier
		------------------------------------------------------------------------
		Parameters:
		- indexST:specific species tree identifier
		Returns:
		- coverage Matrix
		"""
		self.appLogger.debug("Retrieving coverage matrix")
		# coverage matrix per ST - row:indv - col:loci
		# each cov introduced as parameter is a NGSPhyDistribution
		coverageMatrixFilename=os.path.join(\
			self.coverageFolderPath,\
			"{0}.{1:0{2}d}.coverage.csv".format(\
				self.settings.projectName,\
				indexST,\
				self.numSpeciesTreesDigits\
			)
		)

		coverageMatrix=np.zeros(shape=(self.numIndividualsPerSpeciesTree[indexST-1], self.numLociPerSpeciesTree[indexST-1]))
		firstLine=True; counter=0
		with open(coverageMatrixFilename, 'rb') as csvfile:
			coveragereader = csv.reader(csvfile, delimiter=',')
			for row in coveragereader:
				if firstLine:
					firstLine=False
				else:
					coverageMatrix[counter,]=[float(row[index]) for index in range(1,len(row))]
					counter+=1
				if not counter < self.numIndividualsPerSpeciesTree[indexST-1]: break
		return coverageMatrix


	def parseReferenceList(self, filename):
		"""
		Used to parse referenceList, file with format: STID,SPID,TIPID
		-----------------------------------------------------------------------
		Parameters:
		- filename: path of the referenceList file.
		There's only ONE file with the relation of the references
		If "None" inputted (file is missing) then reference by default is 1_0_0
		for all species tree replicates.
		Returns:
		- output: list. each element of the list is a triplet (REPLICATEID,SPID,LOCID,GENEID)
		"""
		self.appLogger.debug("parseReferenceList(self, filename)")
		referenceList=[]
		if filename:
			# There's a file
			filepath=os.path.abspath(filename)
			f=open(filepath,"r")
			lines=f.readlines()
			f.close()
			lines=[line.strip().split(",") for line in lines]
			lines=sorted(lines, key=lambda x:x[1])
			skipped=False
			message="Parsing reference list. "+\
				"A default reference has been introduced.\n"+\
				"Replicate index:"

			index=0; itemIndex=0
			while (index < len(lines)) and (itemIndex < self.numSpeciesTrees):
				d=lines[index]
				if  (int(d[0]) == (itemIndex+1)) and (not "" in d):
					try:
						referenceList+=[(d[0],d[1],d[2],d[3])]
					except IndexError as ie:
						skipped=True
					index+=1
				else: skipped=True

				if skipped:
					self.appLogger.warning("{0}{1}".format(message,(index+1)))
					referenceList+=[(index+1,1,0,0)]
					skipped=False
				itemIndex+=1

			if (itemIndex < self.numSpeciesTrees):
			    for i in range(self.numSpeciesTrees):
			        print([i+1,1,0,0])
		else:
			# iterate get a list with same decription for all species trees
			for item in range(0,self.numSpeciesTrees):
				referenceList+=[(item+1,1,0,0)]
		return referenceList

	def extractTrueVariantsPositions(self, filename):
		"""
		Extract true variant positions from the MSA file used as input
		------------------------------------------------------------------------
		Parameters:
		- filename: MSA fasta file from where to extract the variable positions
		Returns:
		- dictionary. indices=variable sites, content=variable nucleotide set
		"""
		self.appLogger.debug("extractTrueVariantsPositions(self, filename)")
		filepath=os.path.abspath(filename)
		lines=[];variants=dict();seqDescriptions=[]
		numTotalSeqs=0;lenSeq=0; matrix=None
		self.appLogger.debug(\
			"Extracting variable positions from: {0}".format(\
			filepath
		))
		# Checking sequence length
		if isFasta(filepath):
			f=open(filepath)
			lines=f.readlines()
			f.close()
			seq=lines[1] # lines[0] will be a description
			lenSeqs=len(seq.strip())
		else:
			raise TypeError("File has a wrong file format.\n{}\nPlease check. Exiting.".format(filepath))
			# If I get here, function run is over - goes back to  run()

		for item in lines:
			if item.startswith(">"): numTotalSeqs+=1
		matrix=np.chararray((numTotalSeqs,lenSeqs), itemsize=1)
		# Cleaning strings - removing empty lines and removing "\n"
		for index in range(0,len(lines)):
			lines[index]=lines[index].strip()

		try:
		  lines.remove("")
		except: # may raise an exception if list empty (x not in list)
			pass

		numLinesFile=len(lines);index=0
		indexSeqs=range(1,numLinesFile,2)

		for index in range(0,numTotalSeqs):
			seqDescriptions+=[lines[indexSeqs[index]-1]]
			matrix[index,:]=list(lines[indexSeqs[index]])

		for indexCol in range(0,matrix.shape[1]):
			c=Counter(matrix[:,indexCol])
			l=np.unique(matrix[:,indexCol])
			if (len(l)>1):
				variants[str(indexCol)]=c.keys()
		return variants

	def parseIndividualRelationFile(self,filename):
		"""
		Parses "Individual-description relation" file per species tree
		in order to obtain information on how sequences from INDELible
		are related. Generated within NGSPhy.
		------------------------------------------------------------------------
		Parameters:
		- filename: path for the Individual-description relation file
		Returns:
		- if ploidy=1:	returns a dict. key: indID,content: dict(indexST,speciesID,locusID, geneID)
		- if ploidy=2:	returns a dict. key: indID,content: dict(indexST,speciesID,locusID, mateID1,mateID2)
		"""
		self.appLogger.debug("parseIndividualRelationFile(self,filename)")
		individuals=dict()
		if (self.settings.ploidy>0 and self.settings.ploidy<=2):
			csvfile=open(os.path.abspath(filename))
			d = csv.DictReader(csvfile)
			if (self.settings.ploidy==1):
				for row in d:
					individuals[str(row["indID"])] = {\
						"indexST":row["indexST"],\
						"speciesID":row["speciesID"],\
						"locusID":row["locusID"],\
						"geneID":row["geneID"]}
			if (self.settings.ploidy==2):
				# indexST,indID,speciesID,mateID1,mateID2
				for row in d:
					individuals[str(row["indID"])] = {\
						"indexST":row["indexST"],\
						"speciesID":row["speciesID"],\
						"locusID":row["locusID"],\
						"mateID1":row["mateID1"],\
						"mateID2":row["mateID2"]}
			csvfile.close()
		else:
			# There has been a verification in Settings class, but just in case.
			raise ValueError("Ploidy assigned is incorrect. Please verify. Exciting.")
		return individuals

	def getDepthCoveragePerIndividual(self, numVarSites,startingCoverage):
		"""
		Compute coverage per individuals
		since the value for SNPS is fixed to a Negative Binomial distribution
		I iterate over the number of variants for this specific locus and
		since everythime i hit play! (called value()) I'll sample a new value
		from the previously set distribution, i'll then get a random value from a
		negative bionmial distribution with mean max-coverage
		------------------------------------------------------------------------
		Parameters:
		- numVariableSites: number of variable sites
		- startingCoverage: starting value to calculate coverage
		Returns:
		- list of values that correspond to the coverage per each snp of the MSA
		"""
		self.appLogger.debug(\
			"getDepthCoveragePerIndividual(self, numVarSites,startingCoverage) - ({},{})".format(\
				numVarSites,\
				startingCoverage
			))
		distro=ngsphydistro("nb",[startingCoverage,startingCoverage])
		DP=distro.value(numVarSites)
		return DP

	def getHaploidIndividualSequence(self,msa,ind):
		"""
		Extract individuals "ind" sequence(s) from MSA dictionary
		------------------------------------------------------------------------
		Parameters:
		- msa: dictionary
		- ind: dict(indexST,seqDEscription)
		Returns:
		- sequence of the individual
		"""
		# ind: [indID,indexST,seqDescription]
		self.appLogger.debug("getHaploidIndividualSequence(self,msa,ind)")
		seqSize=len(msa["{0}_{1}".format(str(1),str(0))][str(0)]['sequence'])
		fullInd=None; speciesID=None; tipID=None; tmp=None
		fullInd=np.chararray(shape=(1,seqSize), itemsize=1)
		speciesID=ind["speciesID"].strip()
		locusID=ind["locusID"].strip()
		tipID=ind["geneID"].strip()
		tmp=list(msa["{0}_{1}".format(str(speciesID), str(locusID))][str(tipID)]['sequence'])
		fullInd=[item for item in tmp]
		return fullInd

	def getDiploidIndividualSequence(self,msa,ind):
		"""
		Extract individuals "ind" sequence(s) from MSA dictionary
		Parameters:
		- msa: dictionary
		- ind: dict(indexST,speciesID, mateID1,mateID2)
		Returns:
		- matrix: 2 x seqLength - representing the sequence of the individual
		"""
		# ind:[indID, indexST,speciesID, mateID1,mateID2]
		self.appLogger.debug("getDiploidIndividualSequence(self,msa,ind)")
		seqSize=len(msa["1_0"][str(0)]['sequence'])
		fullInd=None;  tmp=None
		speciesID=ind["speciesID"];
		locusID=ind["locusID"];
		tipID1=ind["mateID1"];
		tipID2=ind["mateID2"];
		geneFamily="{0}_{1}".format(speciesID,locusID)
		fullInd=np.chararray(shape=(2,seqSize), itemsize=1)
		tmp=list(msa[geneFamily][str(tipID1)]['sequence'])
		fullInd[0,:]=[item for item in tmp]
		tmp=list(msa[geneFamily][str(tipID2)]['sequence'])
		fullInd[1,:]=[item for item in tmp]
		return fullInd


	def computeHaploid(self,indexST,indexGT,msa,individuals,referenceFilepath,referenceSeqFull,variableSites,DP):
		"""
		compute the READ COUNT for the specic ploidy
		------------------------------------------------------------------------
		Parameters:
		- indexST: species tree id
		- indexGT: locus/gene tree id
		- msa: parsed multiple sequence alignent file (dictionary)
		- individuals: parsed individual-description relation file (dictionary)
		- referenceFilepath: where the reference is written.
		- referenceSeqFull: reference sequence as is
		- variableSites: dictionary. keys: variable positions. content: variable nucleotide set
		- DP: variable sites coverage
		Returns:
		- get a file written in the STreplicate folder (true/sampled)
		"""
		self.appLogger.debug("computeHaploid(msa,individuals,referenceFilepath,referenceSeqFull,variableSites,DP)")
		nInds=len(individuals)
		nVarSites=len(variableSites.keys())
		# Getting the proper indices of the variable sites
		variableSitesPositionIndices=np.sort([int(pos) for pos in variableSites.keys()])
		alt=dict();  altInds=dict()
		rcsTrue=dict();rcsSampled=dict()
		HTGeneral=dict();HLGeneral=dict();ADGeneral=dict()
		HTGeneralSampled=dict();HLGeneralSampled=dict();ADGeneralSampled=dict()
		for pos in variableSites.keys():
			alt[pos]=[]; altInds[pos]=[]
		for pos in variableSitesPositionIndices:
			alt[str(pos)]=list(set(variableSites[str(pos)])-set([referenceSeqFull[pos]]))
		for index in range(0,nInds):
			indexIND=str(index)
			HTGeneral[indexIND]=[];HLGeneral[indexIND]=[];ADGeneral[indexIND]=[]
			HTGeneralSampled[indexIND]=[];
			HLGeneralSampled[indexIND]=[];ADGeneralSampled[indexIND]=[]
			rcsTrue[indexIND]=[];rcsSampled[indexIND]=[]
		########################################################
		# TRUE
		########################################################
		# iterate over individuals

		self.appLogger.debug("True")
		altInd=copy.copy(alt)
		for indIndex in range(0,nInds):
			indexIND=str(indIndex)
			self.appLogger.debug("\tSpecies tree: {0} - Locus {1} |  Individual {2} ({3}/{4})".format(\
				indexST, indexGT,
				indIndex,(indIndex+1),nInds))
			ind=individuals[indexIND]
			individualSeq=self.getHaploidIndividualSequence(msa,ind)
			# individualSeq[202]+="**"
			# AD per individual different if true/sampledInd
			ADTrue,ADSampled=self.getAllelicDepthPerHaploidIndividual(\
				individualSeq,variableSitesPositionIndices,DP[indIndex])
			rcTrue,rcSampled=self.getReadCountPerIndividual(\
				ADTrue,ADSampled,variableSitesPositionIndices)
			altInd=self.getAltUpdatedPerIndividual(\
				referenceSeqFull,altInd,ADSampled)
			HTTrue=self.gettingHaplotype(\
				referenceSeqFull,individualSeq,alt,variableSitesPositionIndices)
			HLTrue=self.haplotypeLikehood(\
				rcTrue,variableSitesPositionIndices,0)
			rcsTrue[indexIND]=rcTrue
			rcsSampled[indexIND]=rcSampled
			ADGeneral[indexIND]=ADTrue
			ADGeneralSampled[indexIND]=ADSampled
			HTGeneral[indexIND]=HTTrue
			HLGeneral[indexIND]=HLTrue

		# here corresponds to the INDEXST that is going to be written
		self.writeVCFFile(\
			indexST,indexGT,\
			referenceFilepath, referenceSeqFull,\
			alt,variableSitesPositionIndices,\
			HTGeneral,HLGeneral,\
			ADGeneral,DP,True)

		########################################################
		# Sampled
		########################################################
		self.appLogger.debug("Sampled")
		for indIndex in range(0,nInds):
			indexIND=str(indIndex)
			self.appLogger.info("Individual {0} ({1}/{2})".format(indIndex,(indIndex+1),nInds))
			ind=individuals[indexIND]
			individualSeq=self.getHaploidIndividualSequence(msa,ind)
			HTGeneralSampled[indexIND]=self.gettingHaplotype(\
				referenceSeqFull,individualSeq,\
				altInd, variableSitesPositionIndices)
			HLGeneralSampled[indexIND]=self.haplotypeLikehood(\
				rcsSampled[indexIND],\
				variableSitesPositionIndices,\
				self.settings.seqerror)

		self.writeVCFFile(
			indexST,indexGT,\
			referenceFilepath, referenceSeqFull,\
			altInd,variableSitesPositionIndices,\
			HTGeneralSampled,HLGeneralSampled,\
			ADGeneralSampled,DP,False)

	def haplotypeLikehood(self,variantsRC,variableSitesPositionIndices,error):
		"""
		computes log10-scaled haplotype likelihood per variable site
		------------------------------------------------------------------------
		Parameters:
		- variantsRC: read count pairs of the variable positions
		- variableSitesPositionIndices: indices of the variable sites position
		- error: sequence error
		Returns:
		- GL: dictionary.
		- keys: positons.
		- content: log10-scaled likelihood for the specific variable site
		"""
		self.appLogger.debug("haplotypeLikehood(self,variantsRC,observed,variableSites,error)")
		nVariants=len(variableSitesPositionIndices)
		HL=np.ones(shape=(4,nVariants), dtype=np.float)
		error=float(error)
		for indexVar in range(0,nVariants):
			indexReads=str(variableSitesPositionIndices[indexVar])
			reads=variantsRC[indexReads]
			# possible haplotypes
			for indexNuc in range(0,4):
				nuc=self.__NUCLEOTIDES[indexNuc]
				# read to be analyzed
				for b in reads:
					if (b.upper()==nuc.upper()):
						HL[indexNuc,indexVar]=HL[indexNuc,indexVar]*(1-error)
					else:
						HL[indexNuc,indexVar]=HL[indexNuc,indexVar]*(error/3)
				# print indexVar, "b: ",b, " A:",nuc,",".join(HL[:,indexVar].astype(str))
		value=np.copy(HL)
		with warnings.catch_warnings():
			warnings.filterwarnings('error')
			try:
				value=np.log10(HL)
			except:
				pass
			infs=np.inf==value
			value[infs]=-300
		return value

	def gettingHaplotype(self,ref,seq,alt, variableSitesPositionIndices):
		"""
		get haplotype for the given ref-seq-alt triplet
		------------------------------------------------------------------------
		Parameters:
		- ref: reference sequence
		- seq: individual sequnece
		- alt: dictionary with alternative alleles per variable position
		- variableSitesPositionIndices: variableSites
		Returns:
		- GT: dictionary. keys: positons. content: haplotype for the specific variable site
		"""
		self.appLogger.debug("gettingHaplotype(self,ref,seq,alt, variableSitesPositionIndices)")
		GT=dict()
		# init variantsRC
		for indexVar in variableSitesPositionIndices:
			GT[str(indexVar)]=0

		for indexVar in variableSitesPositionIndices:
			refPos=ref[indexVar]
			seqPos=seq[indexVar]
			altValues=alt[str(indexVar)]
			iv=str(indexVar)
			for index in range(0,len(altValues)):
				altToCompare=altValues[index]
				if (index==0) and (altToCompare==seqPos):
					GT[iv]=1
				if (index==1) and (altToCompare==seqPos):
					GT[iv]=2
				if (index==2) and (altToCompare==seqPos):
					GT[iv]=3
		return copy.copy(GT)

	def getAltUpdatedPerIndividual(self,ref,alt,AD):
		"""
		update general alternative alleles list
		------------------------------------------------------------------------
		Parameters:
		- referenceSeq: reference sequence
		- alt: dictionary. current alternative allele list per variant
		- AD: allelic depth matrix
		Return:
		- newAlt: dictionary. keys: positions. content: alt alleles corresponding to that position
		"""
		self.appLogger.debug("getAltUpdatedPerIndividual(self,ref,alt,AD)")
		# update alt values
		# Sampled - ALT is a DICT
		# altUpdate is going to be a dict too
		altUpdated=dict()
		for item in alt.keys(): altUpdated[item]=[]
		sortedAltKeys=np.sort([int(item) for item in alt.keys()])
		for index in range(0,len(sortedAltKeys)):
			possibleNucsAlt=[]
			if (AD[0,index]>0): possibleNucsAlt+=["A"]
			if (AD[1,index]>0): possibleNucsAlt+=["C"]
			if (AD[2,index]>0): possibleNucsAlt+=["G"]
			if (AD[3,index]>0): possibleNucsAlt+=["T"]
			newAlt=set(\
					alt[str(sortedAltKeys[index])] + \
					possibleNucsAlt\
				) - \
				set(ref[sortedAltKeys[index]])
			altUpdated[str(sortedAltKeys[index])]+=list(np.sort(list(newAlt)))
		return altUpdated

	def getReadCountPerIndividual(self,ADTrue,ADSampled, variableSitesPositionIndices):
		"""
		generates list of read counts per variant per individual
		------------------------------------------------------------------------
		Parameters:
		- ADTrue: True allelic depth
		- ADSampled: Sampled allelic depth
		- variableSitesPositionIndices: position of the variable sites
		Return:
		- RCTrue, RCSampled.
		"""
		self.appLogger.debug("getReadCountPerIndividual(self,ADTrue,ADSampled, variableSitesPositionIndices)")
		nVariants=len(variableSitesPositionIndices)
		rcTrue=dict();rcSampled=dict()
		# init variantsRC
		for indexVar in range(0,nVariants):
			indexConverted=str(variableSitesPositionIndices[indexVar])
			rcTrue[indexConverted]=[]
			rcSampled[indexConverted]=[]
		# getting read count
		for indexVar in range(0,nVariants):
			for indexNuc in range(0,4):
				with warnings.catch_warnings():
					warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning)
					nuc=[self.__NUCLEOTIDES[indexNuc]]
					indexConverted=str(variableSitesPositionIndices[indexVar])
					val=ADTrue[indexNuc,indexVar]
					rcTrue[indexConverted]+=nuc*val
					val=ADSampled[indexNuc,indexVar]
					rcSampled[indexConverted]+=nuc*val
		return rcTrue, rcSampled

	def getAllelicDepthPerHaploidIndividual(self,individualSeq,variableSitesPositionIndices,DP):
		"""
		Generate allelic depth per individual per site
		------------------------------------------------------------------------
		Parameters:
		- individualSequence: sequence of the individual
		- variableSitesPositionIndices: position of the variable sites
		- DP: coverage of the variable sites
		Returns:
		- ADTrue, ADSampled.
		"""
		self.appLogger.debug("getAllelicDepthPerHaploidIndividual(self,fullInd,variableSites,DP)")
		nVariants=len(variableSitesPositionIndices)
		ADTrue=np.zeros(shape=(4,nVariants), dtype=np.int)
		ADSampled=np.zeros(shape=(4,nVariants), dtype=np.int)
		self.appLogger.debug("Starting to iterate over the variants")
		# There was a problem in this block related to low coverage, error
		# and possible substitutions.
		for indexVar in range(0,nVariants):
			finalRC=[];indNucs=[]
			# getting general coverage per position
			posCoverage=DP[indexVar]
			indexSeq=variableSitesPositionIndices[indexVar]
			indNucs=individualSeq[indexSeq]
			finalRC=[indNucs]*(posCoverage)
			counter=Counter(finalRC)
			# TRUE READ count
			ADTrue[0,indexVar]=counter["A"];ADTrue[1,indexVar]=counter["C"]
			ADTrue[2,indexVar]=counter["G"];ADTrue[3,indexVar]=counter["T"]
			# SAMPLE READ COUNT - need to know error distribution
			errorDistro=ngsphydistro("b",[posCoverage,self.settings.seqerror])
			errorD=errorDistro.value(1)[0]
			errorPositions=[]
			# need to know possible nucleotides to substitute my position with error
			possibleNucs=list(set(self.__NUCLEOTIDES)-set([indNucs]))
			# I have some positions (at least 1) that is an error
			# errorD= array with coded error nucleotides that will be modified
			if (errorD>0):
				errorChoices=np.random.choice(possibleNucs, int(errorD), replace=True)
				maxAvailablePositions=posCoverage
				if not ((posCoverage % 2) == 0): maxAvailablePositions=posCoverage-1
				if maxAvailablePositions == 0:  maxAvailablePositions=posCoverage

				errorPositions=np.random.randint(maxAvailablePositions,size=int(errorD))
				for item in range(0,len(errorPositions)):
					posToChange=errorPositions[item]
					finalRC[posToChange]=errorChoices[item]
			counter=Counter(finalRC)
			# if any of the nucleotides does not have a counter retrieving it will be 0
			ADSampled[0,indexVar]=counter["A"];ADSampled[1,indexVar]=counter["C"]
			ADSampled[2,indexVar]=counter["G"];ADSampled[3,indexVar]=counter["T"]
		return ADTrue,ADSampled

	def computeDiploid(self,indexST,indexGT,msa,individuals,referenceFilepath,referenceSeqFull,variableSites,DP):
		"""
		compute the READ COUNT for the specic ploidy
		------------------------------------------------------------------------
		Parameters:
		- indexST: species tree id
		- indexGT: locus/gene tree id
		- msa: parsed multiple sequence alignent file (dictionary)
		- individuals: parsed individual-description relation file (dictionary)
		- referenceSeqFull: reference sequence as is
		- variableSites: dictionary. keys: variable positions. content: variable nucleotide set
		- DP: variable sites coverage
		Returns:
		- get a file written in the STreplicate folder (true/sampled)
		"""
		self.appLogger.debug("computeDiploid(self,indexST,indexGT,msa,individuals,referenceSeqFull,variableSites,DP)")
		nInds=len(individuals)
		nVarSites=len(variableSites.keys())
		# Getting the proper indices of the variable sites
		variableSitesPositionIndices=np.sort([int(pos) for pos in variableSites.keys()])
		alt=dict();  altInds=dict()
		rcsTrue=dict();rcsSampled=dict()
		GTGeneral=dict();GLGeneral=dict();ADGeneral=dict()
		GTGeneralSampled=dict();GLGeneralSampled=dict();ADGeneralSampled=dict()
		for pos in variableSites.keys():
			alt[pos]=[]; altInds[pos]=[]
		for pos in variableSitesPositionIndices:
			alt[str(pos)]=list(set(variableSites[str(pos)])-set([referenceSeqFull[pos]]))
		for index in range(0,nInds):
			indexIND=str(index)
			GTGeneral[indexIND]=[];GLGeneral[indexIND]=[];ADGeneral[indexIND]=[]
			GTGeneralSampled[indexIND]=[];
			GLGeneralSampled[indexIND]=[];ADGeneralSampled[indexIND]=[]
			rcsTrue[indexIND]=[];rcsSampled[indexIND]=[]
		########################################################
		# DIPLOID TRUE
		########################################################
		# iterate over individuals
		self.appLogger.debug("True")
		altInd=copy.copy(alt)
		for indIndex in range(0,nInds):
			GTTrue=dict()
			indexIND=str(indIndex)
			self.appLogger.debug("\tSpecies tree: {0} - Locus {1} |  Individual {2} ({3}/{4})".format(\
				indexST, indexGT,
				indIndex,(indIndex+1),nInds))
			ind=individuals[indexIND]
			individualSeq=self.getDiploidIndividualSequence(msa,ind)
			ADTrue,ADSampled=self.getAllelicDepthPerDiploidIndividual(\
				individualSeq,variableSitesPositionIndices,DP[indIndex])
			rcTrue,rcSampled=self.getReadCountPerIndividual(\
				ADTrue,ADSampled,variableSitesPositionIndices)
			altInd=self.getAltUpdatedPerIndividual(\
				referenceSeqFull,altInd,ADSampled)
			GTTrueS0=self.gettingHaplotype(
				referenceSeqFull,individualSeq[0,:],\
				alt, variableSitesPositionIndices
			)
			GTTrueS1=self.gettingHaplotype(
				referenceSeqFull,individualSeq[1,:],\
				alt, variableSitesPositionIndices
			)
			for item in variableSitesPositionIndices:
				GTTrue[str(item)]=[GTTrueS0[str(item)],GTTrueS1[str(item)]]
			GLTrue=self.genotypeLikehood(\
				rcTrue,variableSitesPositionIndices,0)
			rcsTrue[indexIND]=rcTrue
			rcsSampled[indexIND]=rcSampled
			ADGeneral[indexIND]=ADTrue
			ADGeneralSampled[indexIND]=ADSampled
			GTGeneral[indexIND]=GTTrue
			GLGeneral[indexIND]=GLTrue

		# here corresponds to the INDEXST that is going to be written
		self.writeVCFFile(\
			indexST,indexGT,\
			referenceFilepath, referenceSeqFull,\
			alt,variableSitesPositionIndices,\
			GTGeneral,GLGeneral,\
			ADGeneral,DP,True)

		########################################################
		# DIPLOID SAMPLED
		########################################################
		self.appLogger.debug("Sampled")
		for indIndex in range(0,nInds):
			GTSampled=dict()
			indexIND=str(indIndex)
			self.appLogger.debug("\tSpecies tree: {0} - Locus {1} |  Individual {2} ({3}/{4})".format(\
				indexST, indexGT,
				indIndex,(indIndex+1),nInds))
			ind=individuals[indexIND]
			individualSeq=self.getDiploidIndividualSequence(msa,ind)
			GTSampledS0=self.gettingHaplotype(
				referenceSeqFull,individualSeq[0,:],\
				altInd, variableSitesPositionIndices
			)
			GTSampledS1=self.gettingHaplotype(
				referenceSeqFull,individualSeq[1,:],\
				altInd, variableSitesPositionIndices
			)
			for item in variableSitesPositionIndices:
				GTSampled[str(item)]=[GTSampledS0[str(item)],GTSampledS1[str(item)]]
			GLSampled=self.genotypeLikehood(\
				rcsSampled[indexIND],\
				variableSitesPositionIndices,\
				self.settings.seqerror)
			GTGeneralSampled[indexIND]=GTSampled
			GLGeneralSampled[indexIND]=GLSampled

		self.writeVCFFile(
			indexST,indexGT,\
			referenceFilepath, referenceSeqFull,\
			altInd,variableSitesPositionIndices,\
			GTGeneralSampled,GLGeneralSampled,\
			ADGeneralSampled,DP,False)

	def genotypeLikehood(self, variantsRC,variableSitesPositionIndices,error):
		"""
		compute the genotype likelihoods of a specific ngs-read-count set
		------------------------------------------------------------------------
		Parameters:
		- variantsRC:
		- variableSitesPositionIndices:
		- error
		Returns:
		- Genotype likelihoods for the given variable positions and error
		"""
		self.appLogger.debug("genotypeLikehood(self, variantsRC,variableSitesPositionIndices,error)")
		nVariants=len(variableSitesPositionIndices)
		GL=dict();GLout=dict() # Initialization of genotypeLikehood variable
		possibleGenotypes=self.getAllPossibleGenotypes()
		for indexVar in variableSitesPositionIndices:
			GL[str(indexVar)]={}
			GLout[str(indexVar)]={}
			for pg in possibleGenotypes:
				gen="".join(pg)
				GL[str(indexVar)][gen]=1
				GLout[str(indexVar)][gen]=1
		# getting likelihoods

		for indexVar in variableSitesPositionIndices:
			for pg in possibleGenotypes:
				gen="".join(pg)
				reads=variantsRC[str(indexVar)]
				for b in reads:
					A1=pg[0];A2=pg[1]
					valAl1=0; valA2=0
					if (b==A1):
						valA1=0.5*(1-error)
					else:
						valA1=0.5*(error/3)
					if (b==A2):
						valA2=0.5*(1-error)
					else:
						valA2=0.5*(error/3)
					GL[str(indexVar)][gen]=\
						GL[str(indexVar)][gen]*(valA1+valA2)
		for indexVar in variableSitesPositionIndices:
			for pg in possibleGenotypes:
				gen="".join(pg)
				value=GL[str(indexVar)][gen]
				if value==0:
					GLout[str(indexVar)][gen]=-300
				else:
					GLout[str(indexVar)][gen]=np.log10(value)
		return GL

	"""
	@function:
		def getAllPossibleGenotypes(self):
	@description:
		Generates all the possible genotypes
	@intput:

	@output:
		returns a dictionary. key: positions. content [A1,A2]
	"""
	def getAllPossibleGenotypes(self):
		self.appLogger.debug("getAllPossibleGenotypes(self)")
		possibleGenotypes=[]
		for pos1 in self.__NUCLEOTIDES:
			for pos2 in self.__NUCLEOTIDES:
				possibleGenotypes+=[[pos1,pos2]]
		return possibleGenotypes

	"""
	@function:
		getPossibleGenotypesPerVariableSite(self,ref,alt, variableSitesPositionIndices):
	@description:
		get the genotypes for a specfic position
	@intput:
		ref
		alt
		variableSitesPositionIndices
	@output:
		returns a dictionary. key: positions. content [A1,A2]
	"""
	def getPossibleGenotypesPerVariableSite(self,ref,alt, variableSitesPositionIndices):
		self.appLogger.debug("getPossibleGenotypesPerVariableSite(self,ref,alt, variableSites)")
		self.appLogger.debug("Getting genotypes")
		possibleGenotypes=dict();elems=dict()
		# Initialization
		for varSite in variableSitesPositionIndices:
			possibleGenotypes[str(varSite)]=[]
			elems[str(varSite)]=[]

		for varSite in variableSitesPositionIndices:
			elems[str(varSite)]=[ref[varSite]]+alt[str(varSite)]

		for indexAlt in elems.keys():
			altPos=elems[indexAlt]
			d=[]
			for pos1 in altPos:
				for pos2 in altPos:
					if not (set([pos1,pos2]) in d):
						d+=[set([pos1,pos2])]
						possibleGenotypes[str(indexAlt)]+=["".join([pos1,pos2])]

		return possibleGenotypes

	def genotypeOrder(self,alleles):
		ordered=[]
		for a in range(0,len(alleles)):
			for b in range(0,(a+1)):
				ordered+=[[alleles[a],alleles[b]]]
		return ordered


	"""
	@function:
		getAllelicDepthPerDiploidIndividual(self,fullInd,variableSites,DP)
	@description:
		Generate allelic depth per individual per site
	@intput:
		individualSequence: sequence of the individual
		variableSitesPositionIndices: position of the variable sites
		DP: coverage of the variable sites
	@output:
		ADTrue, ADSampled.
	"""
	def getAllelicDepthPerDiploidIndividual(self,individualSeq,variableSitesPositionIndices,DP):
		self.appLogger.debug("getAllelicDepthPerDiploidIndividual(self,fullInd,variableSitesPositionIndices,DP)")
		nVariants=len(variableSitesPositionIndices)
		ADTrue=np.zeros(shape=(4,nVariants), dtype=np.int)
		ADSampled=np.zeros(shape=(4,nVariants), dtype=np.int)
		self.appLogger.debug("Starting to iterate over the variants")
		# There was a problem in this block related to low coverage, error
		# and possible substitutions.
		for indexVar in range(0,nVariants):
			finalRC=[];indNucs=[]
			# getting general coverage per position
			posCoverage=DP[indexVar]
			indexSeq=variableSitesPositionIndices[indexVar]
			indNucStrand1=individualSeq[0,indexSeq]
			indNucStrand2=individualSeq[1,indexSeq]
			diploidDistro=ngsphydistro("b",[posCoverage,0.5])
			diploidCoverage=diploidDistro.value(1)[0]
			finalRC=[indNucStrand1]*(diploidCoverage)
			finalRC+=[indNucStrand2]*(posCoverage-diploidCoverage)
			counter=Counter(finalRC)
			# TRUE READ count
			ADTrue[0,indexVar]=counter["A"];ADTrue[1,indexVar]=counter["C"]
			ADTrue[2,indexVar]=counter["G"];ADTrue[3,indexVar]=counter["T"]
			# SAMPLE READ COUNT - need to know error distribution
			errorDistro=ngsphydistro("b",[posCoverage,self.settings.seqerror])
			errorD=errorDistro.value(1)[0]
			errorPositions=[]
			# need to know possible nucleotides to substitute my position with error
			possibleNucs=list(set(self.__NUCLEOTIDES)-set([indNucStrand1]+[indNucStrand2]))
			# I have some positions (at least 1) that is an error
			# errorD= array with coded error nucleotides that will be modified
			if (errorD>0):
				errorChoices=np.random.choice(possibleNucs, int(errorD), replace=True)
				maxAvailablePositions=posCoverage
				if not ((posCoverage % 2) == 0): maxAvailablePositions=posCoverage-1
				if maxAvailablePositions == 0:  maxAvailablePositions=posCoverage

				errorPositions=np.random.randint(maxAvailablePositions,size=int(errorD))
				for item in range(0,len(errorPositions)):
					posToChange=errorPositions[item]
					finalRC[posToChange]=errorChoices[item]
			counter=Counter(finalRC)
			# if any of the nucleotides does not have a counter retrieving it will be 0
			ADSampled[0,indexVar]=counter["A"];ADSampled[1,indexVar]=counter["C"]
			ADSampled[2,indexVar]=counter["G"];ADSampled[3,indexVar]=counter["T"]
		return ADTrue,ADSampled


	"""
	@function:
		formatIndividualDataForVCF(self,ref,alt,variableSites,HT,HL,AD,DP):
	@description:
		gets single individual data formated as a GT:GL:AD:DP VCF column
	@intput:
		reference sequence
		alternative alleles
		variableSitesPositionIndices
		haplotype
		likelihood
		allelic depth
		read depth
	@output:
		string column with information in format: GT:GL:AD:DP
	"""
	def formatIndividualDataForVCF(self,ref,alt,variableSitesPositionIndices,HT,HL,AD,DP):
		self.appLogger.debug("formatIndividualDataForVCF(self,ref,alt,variableSitesPositionIndices,HT,HL,AD,DP)")
		nVariants=len(variableSitesPositionIndices)
		nInds=len(HT.keys())
		allVariants=dict()
		possibleGenotypes=None
		if self.settings.ploidy==2:
			possibleGenotypes=self.getPossibleGenotypesPerVariableSite(ref,alt,variableSitesPositionIndices)

		for indexVAR in variableSitesPositionIndices:
			allVariants[str(indexVAR)]=[]
		# Had an error here, because the alt variable was empty (passed wrong variable name to the function)
		for indexVAR in range(0,nVariants):
			tmpInd=variableSitesPositionIndices[indexVAR]
			for indexIND in range(0,nInds):
				trueRows=None; htPerInd=None; adPerInd=None;hlPerInd=None;
				if self.settings.ploidy==1:
					valuesToCodify=[ref[tmpInd]]+alt[str(tmpInd)]
					trueRows=self.codifySequences(valuesToCodify)
					htPerInd="{}".format(HT[str(indexIND)][str(tmpInd)])
					hlPerInd=",".join(HL[str(indexIND)][trueRows,indexVAR].astype(dtype=int).astype(dtype=np.str))
					adPerInd=",".join(AD[str(indexIND)][trueRows,indexVAR].astype(dtype=int).astype(dtype=np.str))
				if self.settings.ploidy==2:
					valuesToCodify=[ref[tmpInd]]+alt[str(tmpInd)]
					trueRows=["".join(pair) for pair in self.genotypeOrder(valuesToCodify)]
					htVar=HT[str(indexIND)][str(tmpInd)]
					htPerInd="/".join([str(val) for val in htVar])
					hlPerInd=",".join(\
						[str(HL[str(indexIND)][str(tmpInd)][var]) for var in trueRows])
					alleles=self.codifySequences(valuesToCodify)
					adPerInd=",".join(AD[str(indexIND)][alleles,indexVAR].astype(dtype=int).astype(dtype=np.str))

				ind="{0}:{1}:{2}:{3}".format(\
					htPerInd,\
					hlPerInd,\
					adPerInd,\
					DP[indexIND][indexVAR])
				allVariants[str(tmpInd)]+=[ind]

		return allVariants

	"""
		@function:
			codifySequences(self,seq):
		@description:
			codify nucleotidic sequence in numbers
			A=0,C=1,G=2,T=3
		@input:
			seq: nucleotidic sequence (containing only ACGT)
		@output:
			codified nucleotidic sequence in numbers
	"""
	def codifySequences(self,seq):
		# self.appLogger.debug("codifySequences(self,ref)")
		codedRef=[]
		for item in seq:
			if "A"==item: codedRef+=[0]
			if "C"==item: codedRef+=[1]
			if "G"==item: codedRef+=[2]
			if "T"==item: codedRef+=[3]
		return np.array(codedRef)

	"""
	@function:
		writeVCFFile(self, indexST,indexGT,REF,alt,variableSitesPositionIndices,HT,HL,AD,DP,flag):
	@description:
		gets single individual data formated as a GT:GL:AD:DP VCF column
	@intput:
		indexST
		indexGT
		referenceFilepath
		reference sequence
		alternative alleles
		variableSitesPositionIndices
		haplotype
		likelihood
		allelic depth
		read depth
		flag: to indicate whether is true o sampled what's being written
	@output:
		string column with information in format: GT:GL:AD:DP
	"""
	def writeVCFFile(self, indexST,indexGT,referenceFilepath,REF,alt,variableSitesPositionIndices,HT,HL,AD,DP,flag):
		self.appLogger.debug("writeVCFFile(self, indexST,indexGT,REF,alt,variableSites,HT,HL,AD,DP,flag)")
		# flag is either true or sampled
		nInds=len(HT.keys())
		if flag:
			self.appLogger.debug("Writing VCF file (true)")
		else:
			self.appLogger.debug("Writing VCF file (sampled)")
		header="{0}\n{1}={2}\n{3}\n{4}={5}".format(\
			"##fileformat=VCFv4.0",\
			"##fileDate",\
			datetime.datetime.now(),\
			"##source=ngsphy.py",
			"##reference",\
			referenceFilepath
		)
		formatLines="{0}\n{1}\n{2}\n{3}".format(
			"##FORMAT=<ID=GT,Number=1,Type=Integer,Description=\"Genotype\">",\
			"##FORMAT=<ID=GL,Number=1,Type=Integer,Description=\"Log10 scale genotype likelihood\">",\
			"##FORMAT=<ID=AD,Number=1,Type=Integer,Description=\"Allelic Depth\">",\
			"##FORMAT=<ID=DP,Number=1,Type=Integer,Description=\"Depth of coverage\">"
		)

		indnames=["Ind{0}".format(i) for i in range(0,nInds)]
		# filename, file_extension = os.path.splitext('/path/to/somefile.ext')
		headerCols=["#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT"]+indnames
		# CHROM
		numGeneTreeDigits=len(str(self.numLociPerSpeciesTree[(indexST-1)]))
		chromName="ST.{0:0{1}d}.GT.{2:0{3}d}".format(indexST,\
			self.numSpeciesTreesDigits,\
			indexGT,\
			numGeneTreeDigits)
		# POS
		nVariants=len(variableSitesPositionIndices)
		POS=[(item+1) for item in variableSitesPositionIndices]
		# ID
		ID=["ST.{0:0{1}d}.GT.{2:0{3}d}.ID.{4}".format(\
			indexST,\
			self.numSpeciesTreesDigits,\
			indexGT,
			numGeneTreeDigits,\
			ID) for ID in range(1, (nVariants+1))]
		# ALT
		ALT=[ ",".join(alt[str(pos)]) for pos in variableSitesPositionIndices ]
		# qual
		QUAL=[u'\u00B7']*nVariants
		# FILTER
		FILTER=[u'\u00B7']*nVariants
		# INFO
		INFO=[u'\u00B7']*nVariants
		# format
		FORMAT=["GT:GL:AD:DP"]*nVariants
		# extra 9 columns: #CHROM,POS,ID,REF,ALT,QUAL,FILTER,INFO,FORMAT = 9
		nLoci=self.numLociPerSpeciesTree[indexST-1]
		numGeneTreeDigits=len(str(nLoci))
		allVariants=self.formatIndividualDataForVCF(\
			REF,alt,variableSitesPositionIndices,HT,HL,AD,DP)
		outfile=""
		# flag true=true  - Flag false= sampled
		if flag:
			outfile="{0}/{2:0{3}d}/{1}_{2:0{3}d}_{4:0{5}d}_TRUE.vcf".format(\
				self.readcountTrueFolderPath,\
				self.settings.dataPrefix,
				indexST,\
				self.numSpeciesTreesDigits,\
				indexGT,\
				numGeneTreeDigits\
			)
		else:
			outfile="{0}/{2:0{3}d}/{1}_{2:0{3}d}_{4:0{5}d}.vcf".format(\
				self.readcountSampledFolderPath,\
				self.settings.dataPrefix,
				indexST,\
				self.numSpeciesTreesDigits,\
				indexGT,\
				numGeneTreeDigits\
			)


		# before writing i'm getting max width of the lines written per column
		colWidths=self.getColWidhts(\
			chromName,POS,ID,\
			REF,alt,QUAL,FILTER,\
			INFO,FORMAT,\
			allVariants,variableSitesPositionIndices)
		# (sizeChrom,sizePOS,sizeID,sizeREF,sizeALT,sizeQUAL,sizeFILTER,sizeINFO,sizeFORMAT,sizeInds)
		maxLenIndName=max([len(elem) for elem in indnames])
		maxLenIndName=max(colWidths[9], maxLenIndName)
		headerWidths=[maxLenIndName]*len(indnames)
		headerWidths=colWidths+headerWidths
		headerFields=["{0:{1}s}".format(headerCols[indexField],headerWidths[indexField]) for indexField in range(0,len(headerCols))]
		filevcf=open(outfile, 'a')
		filevcf.write("{0}\n{1}\n{2}\n".format(\
			header,\
			formatLines,\
			"\t".join(headerFields)\
			))

		for index in range(0, nVariants):
			# extra 9 columns: #CHROM,POS,ID,REF,ALT,QUAL,FILTER,INFO,FORMAT = 9
			line="{0:{1}s}\t{2:{3}s}\t{4:{5}s}\t{6:{7}s}\t{8:{9}s}\t{10:{11}s}\t{12:{13}s}\t{14:{15}s}\t{16:{17}s}\t{18}\n".format(\
				chromName,colWidths[0],\
				str(POS[index]),colWidths[1],\
				ID[index],colWidths[2],\
				REF[variableSitesPositionIndices[index]],colWidths[3],\
				",".join(alt[str(variableSitesPositionIndices[index])]),colWidths[4],\
				QUAL[index].encode("UTF-8"),colWidths[5],\
				FILTER[index].encode("UTF-8"),colWidths[6],\
				INFO[index].encode("UTF-8"),colWidths[7],\
				FORMAT[index].encode("UTF-8"),colWidths[8],\
				"\t".join(\
					["{0:{1}s}".format(indVar,maxLenIndName) for indVar in allVariants[str(variableSitesPositionIndices[index])]]\
				)
			)
			filevcf.write(line)
		filevcf.close()

	def getColWidhts(self,chromName,POS,ID,REF,ALT,QUAL,FILTER,INFO,FORMAT,allVariants, variableSitesPositionIndices):
		"""
		get string widht of the columns to format the VCF output
		------------------------------------------------------------------------
		Parameters:
		- chromName: data column
		- POS: data column
		- ID: data column
		- REF: data column
		- ALT: data column
		- QUAL: data column
		- FILTER: data column
		- INFO: data column
		- FORMAT: data column
		- allVariants: data column
		- variableSitesPositionIndices: data column
		Returns:
		- list with the leghts of the columns that are going to be written in the VCF file
		"""
		self.appLogger.debug("getColWidhts(self,chromName,POS,ID,REF,ALT,QUAL,FILTER,INFO,FORMAT,allVariants, variableSites)")
		#CHROM,POS,ID,REF,ALT,QUAL,FILTER,INFO,FORMAT
		sizeChrom=len(chromName)
		sizePOS=max([len(str(item)) for item in POS])
		sizeID=max([len(item) for item in ID])
		sizeREF=max([len(item) for item in REF])
		tmpALT=[",".join(ALT[str(var)]) for var in variableSitesPositionIndices]
		sizeALT=max([len(item) for item in tmpALT])
		sizeQUAL=max([len(item) for item in QUAL])
		sizeFILTER=max([len(item) for item in FILTER])
		sizeINFO=max([len(item) for item in INFO])
		sizeFORMAT=max([len(item) for item in FORMAT])
		tmpInds=[]
		for item in variableSitesPositionIndices:
			tmpInds+=[max([ len(elem) for elem in allVariants[str(item)]])]
		sizeInds=max(tmpInds)
		return [sizeChrom,sizePOS,sizeID,sizeREF,sizeALT,sizeQUAL,sizeFILTER,sizeINFO,sizeFORMAT,sizeInds]

	def writeReference(self,indexST,indexGT,referenceSpeciesID,referenceLocusID,referenceTipID,referenceSeqFull):
		"""
		write reference sequence file separately
		------------------------------------------------------------------------
		Parameters:
		- indexST: index of the species tree to which it belongs
		- indexGT: index of the gene tree to which it belongs
		- referenceSpeciesID: species ID to which the reference belongs within a MSA file
		- referenceTipID:  tip ID to which the reference belongs within a species in a MSA file
		- referenceSeqFull: nucleotidic sequence
		Returns:
		- filepath where the reference will be written.
		"""
		self.appLogger.debug(" writeReference(self,indexST,indexGT,referenceSpeciesID,referenceTipID,referenceSeqFull):")
		referenceFilepath="{0}/{3:{4}}/{1}_{2}_REF_{3:0{4}d}_{5:0{6}d}.fasta".format(\
			self.referencesFolderPath,\
			self.settings.projectName,\
			self.settings.dataPrefix,\
			indexST,\
			self.numSpeciesTreesDigits,\
			indexGT,\
			len(str(self.numLociPerSpeciesTree[(indexST-1)]))\
		)
		description=">REFERENCE:{0}:ST.{1:{2}}:GT.{3:{4}}:{5}_{6}_{7}".format(\
			self.settings.dataPrefix,\
			indexST,\
			self.numSpeciesTreesDigits,\
			self.numLociPerSpeciesTree[(indexST-1)],\
			len(str(self.numLociPerSpeciesTree[(indexST-1)])),\
			referenceSpeciesID,\
			referenceLocusID,\
			referenceTipID\
		)
		f=open(referenceFilepath,"w")
		f.write("{0}\n{1}\n".format(\
			description,\
			"".join(referenceSeqFull)
		))
		return referenceFilepath



	def launchCommand(self, referenceForCurrST, indexST,indexGT, individuals,coverageMatrix):
		"""
		Launches the execution ogf the RC computation.
		------------------------------------------------------------------------
		Parameters:
		- referenceForCurrST: reference for current species tree replicate, the
		 one that  will be processed
		- indexST: proper identifier of the species tree replicete
		- indexGT: proper identifier of the gene tree
		- individuals: number of individuals
		- coverageMatrix: coverage matrix
		"""
		try:
			self.appLogger.debug("launchCommand(self, referenceList, indexST,indexGT, individuals,coverageMatrix")
			tStartTime=datetime.datetime.now()
			numIndividuals=len(individuals.keys())
			nLoci=self.numLociPerSpeciesTree[indexST-1]
			self.appLogger.debug("Iterating over nLoci: {0}/{1}".format(indexGT,nLoci))
			numGeneTreeDigits=len(str(nLoci))
			filepathLoc="{0}/{1}/{2:0{3}d}/{4}_{5:0{6}d}_TRUE.fasta".format(\
				self.settings.path,\
				self.settings.projectName,\
				indexST,\
				self.numSpeciesTreesDigits,\
				self.settings.dataPrefix,\
				indexGT,\
				numGeneTreeDigits\
			)
			# dictionary. indices=variable sites, content=variable nucleotide set
			variableSites=self.extractTrueVariantsPositions(filepathLoc)
			nVarSites=len(variableSites.keys())
			self.appLogger.debug(\
				"Species tree: {0}\t Locus: {1}\t - Found [{2}] variable sites.".format(\
					indexST,\
					indexGT,\
					nVarSites))
			# Parse MSA files - dictionary[speciesID][tipID]
			#				   content={description,sequence}
			msa=parseMSAFile(filepathLoc)
			# indices to get the sequence of the REFERENCE!
			tag="{0}_{1}".format(referenceForCurrST[1],referenceForCurrST[2])
			if tag in msa.keys():
				referenceSpeciesID=str(referenceForCurrST[1])
				referenceLocusID=str(referenceForCurrST[2])
				referenceTipID=str(referenceForCurrST[3])
				referenceSeqFull=msa[tag][referenceTipID]['sequence']
				referenceFilepath=self.writeReference(\
					indexST,indexGT,\
					referenceSpeciesID,referenceLocusID,referenceTipID,\
					referenceSeqFull)
				# Coverage per SNP is the same for both true/sampled dataset
				self.appLogger.info("Species tree: {0}\t Locus: {1}\t - Getting coverage per individual per variant".format(\
					indexST,\
					indexGT
				))
				DP=[self.getDepthCoveragePerIndividual(\
						nVarSites,\
						coverageMatrix[index][(indexGT-1)]) \
						for index in range(0,numIndividuals)\
						]
				if self.settings.ploidy==1:
					self.computeHaploid(\
						indexST,indexGT,\
						msa,individuals,\
						referenceFilepath,referenceSeqFull,\
						variableSites,DP)
				if self.settings.ploidy==2:
					self.computeDiploid(\
						indexST,indexGT,\
						msa,individuals,\
						referenceFilepath,referenceSeqFull,\
						variableSites,DP)
				tEndTime=datetime.datetime.now()
				ETA=(tEndTime-tStartTime).total_seconds()
				# row['indexST'],indexLOC,row['indID'],inputFile, outputFile]+callParams]
				outfile="{0}/{2:0{3}d}/{1}_{2:0{3}d}_{4:0{5}d}*".format(\
								self.readcountTrueFolderPath,\
								self.settings.dataPrefix,
								indexST,\
								self.numSpeciesTreesDigits,\
								indexGT,\
								numGeneTreeDigits\
							)
				line=[indexST,indexGT,"-",filepathLoc,ETA,"-",outfile]
				self.runningInfo.addLine(line)
		except KeyboardInterrupt:
			message="{0}{1}Thread has been interrupted!{2}\n".format("\033[91m","\033[1m","\033[0m")
			raise KeyboardInterrupt(message)

	def run(self):
		"""
		Process flow for the generation of read counts
		------------------------------------------------------------------------
		Returns:
		- Boolean indating whether process has finished correctly or not.
		"""
		self.appLogger.debug("run(self)")
		status=True;	message="Read counts finished ok."
		self.appLogger.debug( "Run - read count")
		try:
			# generating folder structure for this part
			self.generateFolderStructureDetail()
			# Get list of reference sequences
			referenceList=self.parseReferenceList(self.settings.readCountsReferenceFilePath)
			nSTS=len(self.filteredST)
			# iterate over the "iterable" species trees / filtered STs
			self.appLogger.info("Running...")
			nProcesses=sum([self.numLociPerSpeciesTree[item-1] for item in self.filteredST])
			currProcessesRunning=1
			pool=multiprocessing.Pool(self.settings.numThreads)

			filepathIndividualsRelations=[\
				"{0}/tables/{1}.{2:0{3}d}.individuals.csv".format(\
				self.settings.outputFolderPath,\
				self.settings.projectName,\
				indexST,\
				self.numSpeciesTreesDigits)\
			for indexST in self.filteredST]

			individualsList=[self.parseIndividualRelationFile(singlefile) for singlefile in filepathIndividualsRelations]
			numIndividualsList=[len(item.keys()) for item in individualsList]
			coverageMatrices=[self.retrieveCoverageMatrix(indexST) for indexST in self.filteredST]
			nLociList=[self.numLociPerSpeciesTree[item-1] for item in self.filteredST]
			ARGS=[(referenceList[item],\
				self.filteredST[item],\
				nLociList[item],\
				individualsList[item],\
				coverageMatrices[item])\
			for item in range(0,nSTS)]

			for indexFilterST in range(0,nSTS):
				indexST=self.filteredST[indexFilterST] # Get Proper ID for ST
				nLoci=nLociList[indexFilterST]
				self.appLogger.debug("Number of individuals: {0}".format(numIndividualsList[indexFilterST]))
				self.appLogger.debug("Number of loci: {0}".format(nLoci))
				indexGT=1
				threadsToBeRan=nLoci
				while indexGT < (nLoci+1):
					# for indexGT in range(1,(nLoci+1)):
					jobs=[]
					for item in range(0,min(self.settings.numThreads, threadsToBeRan)):
						progress=((currProcessesRunning*100)*1.0)/(nProcesses+1)
						currProcessesRunning+=1
						sys.stdout.write("Progress {0:02.1f} %\r".format(progress))
						sys.stdout.flush()
						time.sleep(0.2)
						t = multiprocessing.Process(\
							target=self.launchCommand,\
							args=(\
								referenceList[indexST-1],\
								indexST,\
								indexGT,\
								individualsList[indexFilterST],\
								coverageMatrices[indexFilterST])\
						)
						t.daemon=True
						jobs.append(t)
						t.start()
						indexGT+=1
						threadsToBeRan=(nLoci+1)-indexGT

					for j in jobs:
						j.join()

		except ValueError as ve:
			# If there's a wrong ploidy inserted.
			status=False
			message="\n\t{0}\n\t{1}\n\t{2}".format(\
				"Ploidy value invalid",\
				ve,\
				"Please verify. Exiting.")
		except TypeError as te:
			# One of the files is not fasta.
			status=False
			message=message="\n\t{0}\n\t{1}\n\t{2}".format(\
				"Problem with the file type.",\
				te,\
				"Please verify. Exiting.")
		except Exception as ex:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			message="\n\tUnexpected: {0} | {1} - File: {2} - Line:{3}".format(ex,exc_type, fname, exc_tb.tb_lineno)
			status=False
		return status,message
